# OpenShift Auto-heal Service

This playbook installs the OpenShift Auto-heal service.

For more details see the documentation of the
[role](../roles/openshift_autoheal) that is used to install the service.
