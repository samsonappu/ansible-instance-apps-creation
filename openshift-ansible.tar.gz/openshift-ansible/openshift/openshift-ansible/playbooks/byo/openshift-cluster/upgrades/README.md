# Upgrade playbooks
The playbooks provided in this directory can be used for upgrading an existing
cluster. Additional notes for the associated upgrade playbooks are
provided in their respective directories.

# Upgrades available
- [OpenShift Container Platform 3.11 to 4.0](v4_0/README.md) (upgrade OpenShift Origin from 3.11.x to 4.0.x)
