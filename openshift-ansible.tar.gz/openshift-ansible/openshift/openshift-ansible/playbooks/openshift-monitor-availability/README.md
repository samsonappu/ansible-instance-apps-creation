# OpenShift Availability Monitoring

This playbook runs the [OpenShift Availability Monitoring role](../../roles/openshift_monitor_availability). See the role
for more information.

## GCP Development

The `install-gcp.yml` playbook is useful for ad-hoc installation in an existing GCE cluster.
