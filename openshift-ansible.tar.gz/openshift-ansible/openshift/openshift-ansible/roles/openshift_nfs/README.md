OpenShift NFS
=============

Sets up basic NFS services on a cluster host.

See [tasks/create_export.yml](tasks/create_export.yml) for
instructions on using the export creation tasks file.

License
-------

Apache License, Version 2.0

Author Information
------------------

Tim Bielawa (tbielawa@redhat.com)
