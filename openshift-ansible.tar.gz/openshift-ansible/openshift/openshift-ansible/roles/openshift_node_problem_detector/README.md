Openshift Node Problem Detector
===============================

Install the Node Problem Detector

Role Variables
--------------
Check defaults/main.yml


Example Playbook
----------------

#!/usr/bin/ansible-playbook

Notes
-----

This is currently experimental software.  This role allows users to install the Node Problem Detector and creates a service account with enough permissions to run it.

https://github.com/openshift/node-problem-detector

License
-------

Apache License, Version 2.0

Author Information
------------------

Openshift
